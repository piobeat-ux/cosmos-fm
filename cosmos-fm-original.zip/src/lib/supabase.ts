import { createClient } from '@supabase/supabase-js';
import type { Show, Host, Podcast, Category } from '@/types/database';

// ============================================================
// ВАШИ КЛЮЧИ SUPABASE
// ============================================================
// 1. Зайдите в проект на https://supabase.com
// 2. Перейдите: Project Settings → API
// 3. Скопируйте значения вместо примеров ниже
//
// ПРИМЕР:
// const SUPABASE_URL = 'https://abc123.supabase.co';
// const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIs...';

const SUPABASE_URL: string = '';  // <-- ВСТАВЬТЕ URL ПРОЕКТА
const SUPABASE_ANON_KEY: string = '';  // <-- ВСТАВЬТЕ ANON KEY

// ============================================================
// НИЖЕ НИЧЕГО НЕ МЕНЯЙТЕ
// ============================================================

let supabaseInstance: any = null;

try {
  if (SUPABASE_URL && SUPABASE_URL.includes('supabase.co') && 
      SUPABASE_ANON_KEY && SUPABASE_ANON_KEY.length > 20) {
    supabaseInstance = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
    console.log('[Cosmos FM] Supabase connected successfully');
  } else {
    console.log('[Cosmos FM] Supabase not configured. Using localStorage mode.');
  }
} catch (e) {
  console.warn('[Cosmos FM] Supabase connection failed:', e);
}

export const supabase = supabaseInstance;

function ensureSupabase() {
  if (!supabaseInstance) {
    throw new Error('Supabase not configured. Using localStorage mode.');
  }
}

// ========== SHOWS API ==========
export async function getShows(dayOfWeek?: string): Promise<Show[]> {
  ensureSupabase();
  let query = supabaseInstance.from('shows').select('*').order('time');
  if (dayOfWeek) query = query.eq('day_of_week', dayOfWeek);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export async function createShow(show: Omit<Show, 'id' | 'created_at'>): Promise<Show> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('shows').insert(show).select().single();
  if (error) throw error;
  return data;
}

export async function updateShow(id: string, show: Partial<Show>): Promise<Show> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('shows').update(show).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteShow(id: string): Promise<void> {
  ensureSupabase();
  const { error } = await supabaseInstance.from('shows').delete().eq('id', id);
  if (error) throw error;
}

// ========== HOSTS API ==========
export async function getHosts(): Promise<Host[]> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('hosts').select('*').order('name');
  if (error) throw error;
  return data || [];
}

export async function createHost(host: Omit<Host, 'id' | 'created_at'>): Promise<Host> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('hosts').insert(host).select().single();
  if (error) throw error;
  return data;
}

export async function updateHost(id: string, host: Partial<Host>): Promise<Host> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('hosts').update(host).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteHost(id: string): Promise<void> {
  ensureSupabase();
  const { error } = await supabaseInstance.from('hosts').delete().eq('id', id);
  if (error) throw error;
}

// ========== PODCASTS API ==========
export async function getPodcasts(category?: string): Promise<Podcast[]> {
  ensureSupabase();
  let query = supabaseInstance.from('podcasts').select('*').order('created_at', { ascending: false });
  if (category && category !== 'Все') query = query.eq('category', category);
  const { data, error } = await query;
  if (error) throw error;
  return data || [];
}

export async function createPodcast(podcast: Omit<Podcast, 'id' | 'created_at'>): Promise<Podcast> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('podcasts').insert(podcast).select().single();
  if (error) throw error;
  return data;
}

export async function updatePodcast(id: string, podcast: Partial<Podcast>): Promise<Podcast> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('podcasts').update(podcast).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deletePodcast(id: string): Promise<void> {
  ensureSupabase();
  const { error } = await supabaseInstance.from('podcasts').delete().eq('id', id);
  if (error) throw error;
}

// ========== CATEGORIES API ==========
export async function getCategories(): Promise<Category[]> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('categories').select('*').order('name');
  if (error) throw error;
  return data || [];
}

export async function createCategory(category: Omit<Category, 'id' | 'created_at'>): Promise<Category> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('categories').insert(category).select().single();
  if (error) throw error;
  return data;
}

export async function updateCategory(id: string, category: Partial<Category>): Promise<Category> {
  ensureSupabase();
  const { data, error } = await supabaseInstance.from('categories').update(category).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteCategory(id: string): Promise<void> {
  ensureSupabase();
  const { error } = await supabaseInstance.from('categories').delete().eq('id', id);
  if (error) throw error;
}

// ========== REALTIME ==========
export function subscribeToShows(callback: (shows: Show[]) => void) {
  if (!supabaseInstance) return { unsubscribe: () => {} };
  return supabaseInstance
    .channel('shows_changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'shows' }, () => {
      getShows().then(callback);
    })
    .subscribe();
}

export function subscribeToHosts(callback: (hosts: Host[]) => void) {
  if (!supabaseInstance) return { unsubscribe: () => {} };
  return supabaseInstance
    .channel('hosts_changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'hosts' }, () => {
      getHosts().then(callback);
    })
    .subscribe();
}

export function subscribeToPodcasts(callback: (podcasts: Podcast[]) => void) {
  if (!supabaseInstance) return { unsubscribe: () => {} };
  return supabaseInstance
    .channel('podcasts_changes')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'podcasts' }, () => {
      getPodcasts().then(callback);
    })
    .subscribe();
}
