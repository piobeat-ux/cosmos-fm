import { useState } from 'react';
import { Clock, User, Radio } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DataTable } from '@/admin/components/DataTable';
import { ModalForm } from '@/admin/components/ModalForm';
import type { Show } from '@/types/database';
import { DAYS_OF_WEEK } from '@/types/database';

const CATEGORIES = ['Утреннее шоу', 'Новости', 'Музыка', 'Разговорное', 'Бизнес', 'Обучение', 'Кулинария', 'Развлечения', 'Подкаст'];

export function ShowsPage() {
  const { shows, addShow, editShow, removeShow, hosts } = useData();
  const [modalOpen, setModalOpen] = useState(false);
  const [editingShow, setEditingShow] = useState<Show | undefined>();

  const hostNames = hosts.map(h => h.name);

  const handleAdd = () => {
    setEditingShow(undefined);
    setModalOpen(true);
  };

  const handleEdit = (show: Show) => {
    setEditingShow(show);
    setModalOpen(true);
  };

  const handleSubmit = async (data: any) => {
    if (editingShow) {
      await editShow(editingShow.id, data);
    } else {
      await addShow(data);
    }
    setModalOpen(false);
  };

  const formFields = [
    { name: 'title', label: 'Название', type: 'text' as const, required: true, placeholder: 'Например: Утренний кофе' },
    { name: 'description', label: 'Описание', type: 'textarea' as const, placeholder: 'Краткое описание передачи' },
    { name: 'host', label: 'Ведущий', type: 'select' as const, required: true, options: hostNames.length > 0 ? hostNames : ['Анна Петрова', 'Михаил Соколов', 'Елена Волкова'] },
    { name: 'time', label: 'Время начала', type: 'text' as const, required: true, placeholder: '07:00' },
    { name: 'duration', label: 'Длительность', type: 'text' as const, required: true, placeholder: '3ч' },
    { name: 'category', label: 'Категория', type: 'select' as const, required: true, options: CATEGORIES },
    { name: 'day_of_week', label: 'День недели', type: 'select' as const, required: true, options: [...DAYS_OF_WEEK] },
    { name: 'is_live', label: 'Прямой эфир', type: 'checkbox' as const },
  ];

  const columns = [
    { key: 'title', header: 'Название' },
    { key: 'host', header: 'Ведущий', render: (s: Show) => (
      <div className="flex items-center gap-2">
        <User className="w-4 h-4 text-[#71717a]" />
        <span>{s.host}</span>
      </div>
    )},
    { key: 'time', header: 'Время', render: (s: Show) => (
      <div className="flex items-center gap-2">
        <Clock className="w-4 h-4 text-[#6366f1]" />
        <span>{s.time}</span>
      </div>
    )},
    { key: 'day_of_week', header: 'День' },
    { key: 'category', header: 'Категория', render: (s: Show) => (
      <span className={`inline-flex px-2 py-1 rounded-full text-xs ${
        s.category === 'Утреннее шоу' ? 'bg-[#f59e0b]/20 text-[#f59e0b]' :
        s.category === 'Новости' ? 'bg-[#3b82f6]/20 text-[#3b82f6]' :
        s.category === 'Музыка' ? 'bg-[#8b5cf6]/20 text-[#8b5cf6]' :
        s.category === 'Разговорное' ? 'bg-[#22c55e]/20 text-[#22c55e]' :
        'bg-[#6366f1]/20 text-[#6366f1]'
      }`}>
        {s.category}
      </span>
    )},
    { key: 'is_live', header: 'Статус', render: (s: Show) => (
      s.is_live ? (
        <span className="flex items-center gap-1 text-xs text-[#ef4444]">
          <Radio className="w-3 h-3" /> LIVE
        </span>
      ) : (
        <span className="text-xs text-[#71717a]">Запись</span>
      )
    )},
  ];

  return (
    <div>
      <DataTable
        title="Передачи"
        items={shows}
        columns={columns}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={removeShow}
        searchFields={['title', 'host', 'category']}
      />
      <ModalForm
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onSubmit={handleSubmit}
        title={editingShow ? 'Редактировать передачу' : 'Новая передача'}
        fields={formFields}
        initialData={editingShow}
      />
    </div>
  );
}
